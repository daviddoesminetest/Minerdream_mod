-----------------alloys n stuff---------


minetest.register_craft({
	output = 'minerdream:brass_nugget',
	recipe = {
		{'minerdream:casing', 'minerdream:casing', 'minerdream:casing'},
		{'minerdream:casing', 'minerdream:casing', 'minerdream:casing'},
		{'minerdream:casing', 'minerdream:casing', 'minerdream:casing'},
	}
})

minetest.register_craft({
	output = 'minerdream:brass_bar',
	recipe = {
		{'minerdream:brass_nugget', 'minerdream:brass_nugget', ''},
		{'minerdream:brass_nugget', 'minerdream:brass_nugget', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:brass_bar 3',
	recipe = {
		{'default:copper_ingot', 'default:copper_ingot', 'minerdream:zinc_bar'},
	}
})

minetest.register_craft({
	output = 'minerdream:stainlesssteel_bar 1',
	recipe = {
		{'default:steel_ingot', 'minerdream:zinc_bar', 'default:coal_lump'},
	}
})

minetest.register_craft({
	output = 'minerdream:steelstick 3',
	recipe = {
		{'', 'minerdream:stainlesssteel_bar', ''},
		{'', 'minerdream:stainlesssteel_bar', ''},
	}
})

-------------mineralsmelting----------

minetest.register_craft({
	type = "cooking",
	cooktime = 2,
	output = "minerdream:potassium_bar",
	recipe = "minerdream:potassium_lump",
})

minetest.register_craft({
	type = "cooking",
	cooktime = 2,
	output = "minerdream:calcium_bar",
	recipe = "minerdream:calcium_lump",
})

minetest.register_craft({
	type = "cooking",
	cooktime = 4,
	output = "minerdream:nickel_bar",
	recipe = "minerdream:nickel_lump",
})

minetest.register_craft({
	type = "cooking",
	cooktime = 4,
	output = "minerdream:lead_bar",
	recipe = "minerdream:lead_lump",
})

minetest.register_craft({
	type = "cooking",
	cooktime = 4,
	output = "minerdream:zinc_bar",
	recipe = "minerdream:zinc_lump",
})

minetest.register_craft({
	type = "cooking",
	cooktime = 8,
	output = "minerdream:silver_bar",
	recipe = "minerdream:silver_lump",
})

minetest.register_craft({
	type = "cooking",
	cooktime = 8,
	output = "minerdream:lead_bar",
	recipe = "minerdream:lead_lump",
})

minetest.register_craft({
	type = "cooking",
	cooktime = 32,
	output = "minerdream:aluminum_bar",
	recipe = "minerdream:aluminum_lump",
})

minetest.register_craft({
	type = "cooking",
	cooktime = 16,
	output = "minerdream:platinum_bar",
	recipe = "minerdream:platinum_lump",
})

minetest.register_craft({
	type = "cooking",
	cooktime = 32,
	output = "minerdream:cobalt_bar",
	recipe = "minerdream:cobalt_lump",
})

minetest.register_craft({
	type = "cooking",
	cooktime = 32,
	output = "minerdream:ruthenium_bar",
	recipe = "minerdream:ruthenium_lump",
})

-------------mineral blocks-------

minetest.register_craft({
	output = 'minerdream:ruthenium_block',
	recipe = {
		{'minerdream:ruthenium_bar', 'minerdream:ruthenium_bar', 'minerdream:ruthenium_bar'},
		{'minerdream:ruthenium_bar', 'minerdream:ruthenium_bar', 'minerdream:ruthenium_bar'},
		{'minerdream:ruthenium_bar', 'minerdream:ruthenium_bar', 'minerdream:ruthenium_bar'},
	}
})

minetest.register_craft({
	output = 'minerdream:ruthenium_bar 9',
	recipe = {
		{'minerdream:ruthenium_block'},
	}
})

minetest.register_craft({
	output = 'minerdream:cobalt_block',
	recipe = {
		{'minerdream:cobalt_bar', 'minerdream:cobalt_bar', 'minerdream:cobalt_bar'},
		{'minerdream:cobalt_bar', 'minerdream:cobalt_bar', 'minerdream:cobalt_bar'},
		{'minerdream:cobalt_bar', 'minerdream:cobalt_bar', 'minerdream:cobalt_bar'},
	}
})

minetest.register_craft({
	output = 'minerdream:cobalt_bar 9',
	recipe = {
		{'minerdream:cobalt_block'},
	}
})

minetest.register_craft({
	output = 'minerdream:platinum_block',
	recipe = {
		{'minerdream:platinum_bar', 'minerdream:platinum_bar', 'minerdream:platinum_bar'},
		{'minerdream:platinum_bar', 'minerdream:platinum_bar', 'minerdream:platinum_bar'},
		{'minerdream:platinum_bar', 'minerdream:platinum_bar', 'minerdream:platinum_bar'},
	}
})

minetest.register_craft({
	output = 'minerdream:platinum_bar 9',
	recipe = {
		{'minerdream:platinum_block'},
	}
})

minetest.register_craft({
	output = 'minerdream:aluminum_block',
	recipe = {
		{'minerdream:aluminum_bar', 'minerdream:aluminum_bar', 'minerdream:aluminum_bar'},
		{'minerdream:aluminum_bar', 'minerdream:aluminum_bar', 'minerdream:aluminum_bar'},
		{'minerdream:aluminum_bar', 'minerdream:aluminum_bar', 'minerdream:aluminum_bar'},
	}
})

minetest.register_craft({
	output = 'minerdream:aluminum_bar 9',
	recipe = {
		{'minerdream:aluminum_block'},
	}
})

minetest.register_craft({
	output = 'minerdream:zinc_block',
	recipe = {
		{'minerdream:zinc_bar', 'minerdream:zinc_bar', 'minerdream:zinc_bar'},
		{'minerdream:zinc_bar', 'minerdream:zinc_bar', 'minerdream:zinc_bar'},
		{'minerdream:zinc_bar', 'minerdream:zinc_bar', 'minerdream:zinc_bar'},
	}
})

minetest.register_craft({
	output = 'minerdream:zinc_bar 9',
	recipe = {
		{'minerdream:zinc_block'},
	}
})

minetest.register_craft({
	output = 'minerdream:lead_block',
	recipe = {
		{'minerdream:lead_bar', 'minerdream:lead_bar', 'minerdream:lead_bar'},
		{'minerdream:lead_bar', 'minerdream:lead_bar', 'minerdream:lead_bar'},
		{'minerdream:lead_bar', 'minerdream:lead_bar', 'minerdream:lead_bar'},
	}
})

minetest.register_craft({
	output = 'minerdream:lead_bar 9',
	recipe = {
		{'minerdream:lead_block'},
	}
})

minetest.register_craft({
	output = 'minerdream:brass_block',
	recipe = {
		{'minerdream:brass_bar', 'minerdream:brass_bar', 'minerdream:brass_bar'},
		{'minerdream:brass_bar', 'minerdream:brass_bar', 'minerdream:brass_bar'},
		{'minerdream:brass_bar', 'minerdream:brass_bar', 'minerdream:brass_bar'},
	}
})

minetest.register_craft({
	output = 'minerdream:brass_bar 9',
	recipe = {
		{'minerdream:brass_block'},
	}
})

minetest.register_craft({
	output = 'minerdream:silver_block',
	recipe = {
		{'minerdream:silver_bar', 'minerdream:silver_bar', 'minerdream:silver_bar'},
		{'minerdream:silver_bar', 'minerdream:silver_bar', 'minerdream:silver_bar'},
		{'minerdream:silver_bar', 'minerdream:silver_bar', 'minerdream:silver_bar'},
	}
})

minetest.register_craft({
	output = 'minerdream:silver_bar 9',
	recipe = {
		{'minerdream:silver_block'},
	}
})

minetest.register_craft({
	output = 'minerdream:potassium_block',
	recipe = {
		{'minerdream:potassium_bar', 'minerdream:potassium_bar', 'minerdream:potassium_bar'},
		{'minerdream:potassium_bar', 'minerdream:potassium_bar', 'minerdream:potassium_bar'},
		{'minerdream:potassium_bar', 'minerdream:potassium_bar', 'minerdream:potassium_bar'},
	}
})

minetest.register_craft({
	output = 'minerdream:potassium_bar 9',
	recipe = {
		{'minerdream:potassium_block'},
	}
})

minetest.register_craft({
	output = 'minerdream:calcium_block',
	recipe = {
		{'minerdream:calcium_bar', 'minerdream:calcium_bar', 'minerdream:calcium_bar'},
		{'minerdream:calcium_bar', 'minerdream:calcium_bar', 'minerdream:calcium_bar'},
		{'minerdream:calcium_bar', 'minerdream:calcium_bar', 'minerdream:calcium_bar'},
	}
})

minetest.register_craft({
	output = 'minerdream:calcium_bar 9',
	recipe = {
		{'minerdream:calcium_block'},
	}
})

minetest.register_craft({
	output = 'minerdream:nickel_block',
	recipe = {
		{'minerdream:nickel_bar', 'minerdream:nickel_bar', 'minerdream:nickel_bar'},
		{'minerdream:nickel_bar', 'minerdream:nickel_bar', 'minerdream:nickel_bar'},
		{'minerdream:nickel_bar', 'minerdream:nickel_bar', 'minerdream:nickel_bar'},
	}
})

minetest.register_craft({
	output = 'minerdream:nickel_bar 9',
	recipe = {
		{'minerdream:nickel_block'},
	}
})

----------bar stacks---------------

minetest.register_craft({
	output = 'minerdream:ruthenium_bar_block',
	recipe = {
		{'minerdream:ruthenium_bar', 'minerdream:ruthenium_bar', ''},
		{'minerdream:ruthenium_bar', 'minerdream:ruthenium_bar', ''},

	}
})

minetest.register_craft({
	output = 'minerdream:ruthenium_bar 4',
	recipe = {
		{'minerdream:ruthenium_bar_block', '', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:cobalt_bar_block',
	recipe = {
		{'minerdream:cobalt_bar', 'minerdream:cobalt_bar', ''},
		{'minerdream:cobalt_bar', 'minerdream:cobalt_bar', ''},

	}
})

minetest.register_craft({
	output = 'minerdream:cobalt_bar 4',
	recipe = {
		{'minerdream:cobalt_bar_block', '', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:platinum_bar_block',
	recipe = {
		{'minerdream:platinum_bar', 'minerdream:platinum_bar', ''},
		{'minerdream:platinum_bar', 'minerdream:platinum_bar', ''},

	}
})

minetest.register_craft({
	output = 'minerdream:platinum_bar 4',
	recipe = {
		{'minerdream:platinum_bar_block', '', ''},
	}
})


minetest.register_craft({
	output = 'minerdream:aluminum_bar_block',
	recipe = {
		{'minerdream:aluminum_bar', 'minerdream:aluminum_bar', ''},
		{'minerdream:aluminum_bar', 'minerdream:aluminum_bar', ''},

	}
})

minetest.register_craft({
	output = 'minerdream:aluminum_bar 4',
	recipe = {
		{'minerdream:aluminum_bar_block', '', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:brass_bar_block',
	recipe = {
		{'minerdream:brass_bar', 'minerdream:brass_bar', ''},
		{'minerdream:brass_bar', 'minerdream:brass_bar', ''},

	}
})

minetest.register_craft({
	output = 'minerdream:brass_bar 4',
	recipe = {
		{'minerdream:brass_bar_block', '', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:gold_bar_block',
	recipe = {
		{'default:gold_ingot', 'default:gold_ingot', ''},
		{'default:gold_ingot', 'default:gold_ingot', ''},

	}
})

minetest.register_craft({
	output = 'default:gold_ingot 4',
	recipe = {
		{'minerdream:gold_bar_block', '', ''},
	}
})


minetest.register_craft({
	output = 'minerdream:tin_bar_block',
	recipe = {
		{'default:tin_ingot', 'default:tin_ingot', ''},
		{'default:tin_ingot', 'default:tin_ingot', ''},

	}
})

minetest.register_craft({
	output = 'default:tin_ingot 4',
	recipe = {
		{'minerdream:tin_bar_block', '', ''},
	}
})

minetest.register_craft({
	output = 'default:copper_ingot 4',
	recipe = {
		{'minerdream:copper_bar_block', '', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:copper_bar_block',
	recipe = {
		{'default:copper_ingot', 'default:copper_ingot', ''},
		{'default:copper_ingot', 'default:copper_ingot', ''},

	}
})

minetest.register_craft({
	output = 'default:steel_ingot 4',
	recipe = {
		{'minerdream:steel_bar_block', '', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:steel_bar_block',
	recipe = {
		{'default:steel_ingot', 'default:steel_ingot', ''},
		{'default:steel_ingot', 'default:steel_ingot', ''},

	}
})

minetest.register_craft({
	output = 'default:bronze_ingot 4',
	recipe = {
		{'minerdream:bronze_bar_block', '', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:bronze_bar_block',
	recipe = {
		{'default:bronze_ingot', 'default:bronze_ingot', ''},
		{'default:bronze_ingot', 'default:bronze_ingot', ''},

	}
})

minetest.register_craft({
	output = 'minerdream:potassium_bar 4',
	recipe = {
		{'minerdream:potassium_bar_block', '', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:potassium_bar_block',
	recipe = {
		{'minerdream:potassium_bar', 'minerdream:potassium_bar', ''},
		{'minerdream:potassium_bar', 'minerdream:potassium_bar', ''},

	}
})

minetest.register_craft({
	output = 'minerdream:calcium_bar 4',
	recipe = {
		{'minerdream:calcium_bar_block', '', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:calcium_bar_block',
	recipe = {
		{'minerdream:calcium_bar', 'minerdream:calcium_bar', ''},
		{'minerdream:calcium_bar', 'minerdream:calcium_bar', ''},

	}
})

minetest.register_craft({
	output = 'minerdream:nickel_bar 4',
	recipe = {
		{'minerdream:nickel_bar_block', '', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:nickel_bar_block',
	recipe = {
		{'minerdream:nickel_bar', 'minerdream:nickel_bar', ''},
		{'minerdream:nickel_bar', 'minerdream:nickel_bar', ''},

	}
})

minetest.register_craft({
	output = 'minerdream:silver_bar 4',
	recipe = {
		{'minerdream:silver_bar_block', '', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:silver_bar_block',
	recipe = {
		{'minerdream:silver_bar', 'minerdream:silver_bar', ''},
		{'minerdream:silver_bar', 'minerdream:silver_bar', ''},

	}
})

minetest.register_craft({
	output = 'minerdream:zinc_bar 4',
	recipe = {
		{'minerdream:zinc_bar_block', '', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:zinc_bar_block',
	recipe = {
		{'minerdream:zinc_bar', 'minerdream:zinc_bar', ''},
		{'minerdream:zinc_bar', 'minerdream:zinc_bar', ''},

	}
})

minetest.register_craft({
	output = 'minerdream:lead_bar 4',
	recipe = {
		{'minerdream:lead_bar_block', '', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:lead_bar_block',
	recipe = {
		{'minerdream:lead_bar', 'minerdream:lead_bar', ''},
		{'minerdream:lead_bar', 'minerdream:lead_bar', ''},

	}
})

-----------metal bricks--------------

minetest.register_craft( {
	type = "shapeless",
	output = "minerdream:ruthenium_brick",
	recipe = {"minerdream:ruthenium_lump", "default:cobble"},
})

minetest.register_craft( {
	type = "shapeless",
	output = "minerdream:cobalt_brick",
	recipe = {"minerdream:cobalt_lump", "default:cobble"},
})

minetest.register_craft( {
	type = "shapeless",
	output = "minerdream:platinum_brick",
	recipe = {"minerdream:platinum_lump", "default:cobble"},
})

minetest.register_craft( {
	type = "shapeless",
	output = "minerdream:aluminum_brick",
	recipe = {"minerdream:aluminum_lump", "default:cobble"},
})


minetest.register_craft({
	output = 'minerdream:brass_brick',
	recipe = {
		{'', 'minerdream:brass_nugget', ''},
		{'minerdream:brass_nugget', 'default:cobble', 'minerdream:brass_nugget'},
		{'', 'minerdream:brass_nugget', ''},
	}
})

minetest.register_craft( {
	type = "shapeless",
	output = "minerdream:copper_brick",
	recipe = {"default:copper_lump", "default:cobble"},
})

minetest.register_craft( {
	type = "shapeless",
	output = "minerdream:tin_brick",
	recipe = {"default:tin_lump", "default:cobble"},
})

minetest.register_craft( {
	type = "shapeless",
	output = "minerdream:iron_brick",
	recipe = {"default:iron_lump", "default:cobble"},
})

minetest.register_craft( {
	type = "shapeless",
	output = "minerdream:gold_brick",
	recipe = {"default:gold_lump", "default:cobble"},
})

minetest.register_craft( {
	type = "shapeless",
	output = "minerdream:zinc_brick",
	recipe = {"minerdream:zinc_lump", "default:cobble"},
})

minetest.register_craft( {
	type = "shapeless",
	output = "minerdream:lead_brick",
	recipe = {"minerdream:lead_lump", "default:cobble"},
})

minetest.register_craft( {
	type = "shapeless",
	output = "minerdream:nickel_brick",
	recipe = {"minerdream:nickel_lump", "default:cobble"},
})

minetest.register_craft( {
	type = "shapeless",
	output = "minerdream:calcium_brick",
	recipe = {"minerdream:calcium_lump", "default:cobble"},
})

minetest.register_craft( {
	type = "shapeless",
	output = "minerdream:potassium_brick",
	recipe = {"minerdream:potassium_lump", "default:cobble"},
})

minetest.register_craft( {
	type = "shapeless",
	output = "minerdream:silver_brick",
	recipe = {"minerdream:silver_lump", "default:cobble"},
})


--------------misc items-------------

minetest.register_craft( {
	type = "shapeless",
	output = "minerdream:vitamin 6",
	recipe = {"default:iron_lump", "minerdream:calcium_lump", "minerdream:potassium_lump", "minerdream:zinc_lump"},
})

------------spears---------------

minetest.register_craft({
	output = 'minerdream:spear_bronze',
	recipe = {
		{'', 'default:bronze_ingot', 'default:bronze_ingot'},
		{'', 'group:stick', 'default:bronze_ingot'},
		{'group:stick', '', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:spear_steel',
	recipe = {
		{'', 'default:steel_ingot', 'default:steel_ingot'},
		{'', 'group:stick', 'default:steel_ingot'},
		{'group:stick', '', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:spear_lead',
	recipe = {
		{'', 'minerdream:lead_bar', 'minerdream:lead_bar'},
		{'', 'group:stick', 'minerdream:lead_bar'},
		{'group:stick', '', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:spear_stainlesssteel',
	recipe = {
		{'', 'minerdream:stainlesssteel_bar', 'minerdream:stainlesssteel_bar'},
		{'', 'group:stick', 'minerdream:stainlesssteel_bar'},
		{'group:stick', '', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:spear_gold',
	recipe = {
		{'', 'default:gold_ingot', 'default:gold_ingot'},
		{'', 'group:stick', 'default:gold_ingot'},
		{'group:stick', '', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:spear_diamond',
	recipe = {
		{'', 'default:diamond', 'default:diamond'},
		{'', 'group:stick', 'default:diamond'},
		{'group:stick', '', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:spear_mese',
	recipe = {
		{'', 'default:mese_crystal', 'default:mese_crystal'},
		{'', 'group:stick', 'default:mese_crystal'},
		{'group:stick', '', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:spear_nickel',
	recipe = {
		{'', 'minerdream:nickel_bar', 'minerdream:nickel_bar'},
		{'', 'group:stick', 'minerdream:nickel_bar'},
		{'group:stick', '', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:spear_silver',
	recipe = {
		{'', 'minerdream:silver_bar', 'minerdream:silver_bar'},
		{'', 'group:stick', 'minerdream:silver_bar'},
		{'group:stick', '', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:spear_aluminum',
	recipe = {
		{'', 'minerdream:aluminum_bar', 'minerdream:aluminum_bar'},
		{'', 'group:stick', 'minerdream:aluminum_bar'},
		{'group:stick', '', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:spear_platinum',
	recipe = {
		{'', 'minerdream:platinum_bar', 'minerdream:platinum_bar'},
		{'', 'group:stick', 'minerdream:platinum_bar'},
		{'group:stick', '', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:spear_cobalt',
	recipe = {
		{'', 'minerdream:cobalt_bar', 'minerdream:cobalt_bar'},
		{'', 'minerdream:steelstick', 'minerdream:cobalt_bar'},
		{'minerdream:steelstick', '', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:spear_flint',
	recipe = {
		{'', 'default:flint', 'default:flint'},
		{'', 'group:stick', 'default:flint'},
		{'group:stick', '', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:spear_ruthenium',
	recipe = {
		{'', 'minerdream:ruthenium_bar', 'minerdream:ruthenium_bar'},
		{'', 'minerdream:steelstick', 'minerdream:ruthenium_bar'},
		{'minerdream:steelstick', '', ''},
	}
})

--------------------bows----------------


minetest.register_craft({
	output = 'minerdream:bow_copper',
	recipe = {
		{'', 'default:copper_ingot', 'default:copper_ingot'},
		{'default:copper_ingot', '', 'farming:cotton'},
		{'default:copper_ingot', 'farming:cotton', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:bow_tin',
	recipe = {
		{'', 'default:tin_ingot', 'default:tin_ingot'},
		{'default:tin_ingot', '', 'farming:cotton'},
		{'default:tin_ingot', 'farming:cotton', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:bow_bronze',
	recipe = {
		{'', 'default:bronze_ingot', 'default:bronze_ingot'},
		{'default:bronze_ingot', '', 'farming:cotton'},
		{'default:bronze_ingot', 'farming:cotton', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:bow_steel',
	recipe = {
		{'', 'default:steel_ingot', 'default:steel_ingot'},
		{'default:steel_ingot', '', 'farming:cotton'},
		{'default:steel_ingot', 'farming:cotton', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:bow_lead',
	recipe = {
		{'', 'minerdream:lead_bar', 'minerdream:lead_bar'},
		{'minerdream:lead_bar', '', 'farming:cotton'},
		{'minerdream:lead_bar', 'farming:cotton', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:bow_stainlesssteel',
	recipe = {
		{'', 'minerdream:stainlesssteel_bar', 'minerdream:stainlesssteel_bar'},
		{'minerdream:stainlesssteel_bar', '', 'farming:cotton'},
		{'minerdream:stainlesssteel_bar', 'farming:cotton', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:bow_gold',
	recipe = {
		{'', 'default:gold_ingot', 'default:gold_ingot'},
		{'default:gold_ingot', '', 'farming:cotton'},
		{'default:gold_ingot', 'farming:cotton', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:bow_mese',
	recipe = {
		{'', 'default:mese_crystal', 'default:mese_crystal'},
		{'default:mese_crystal', '', 'farming:cotton'},
		{'default:mese_crystal', 'farming:cotton', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:bow_diamond',
	recipe = {
		{'', 'default:diamond', 'default:diamond'},
		{'default:diamond', '', 'farming:cotton'},
		{'default:diamond', 'farming:cotton', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:bow_nickel',
	recipe = {
		{'', 'minerdream:nickel_bar', 'minerdream:nickel_bar'},
		{'minerdream:nickel_bar', '', 'farming:cotton'},
		{'minerdream:nickel_bar', 'farming:cotton', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:bow_silver',
	recipe = {
		{'', 'minerdream:silver_bar', 'minerdream:silver_bar'},
		{'minerdream:silver_bar', '', 'farming:cotton'},
		{'minerdream:silver_bar', 'farming:cotton', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:bow_aluminum',
	recipe = {
		{'', 'minerdream:aluminum_bar', 'minerdream:aluminum_bar'},
		{'minerdream:aluminum_bar', '', 'farming:cotton'},
		{'minerdream:aluminum_bar', 'farming:cotton', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:bow_platinum',
	recipe = {
		{'', 'minerdream:platinum_bar', 'minerdream:platinum_bar'},
		{'minerdream:platinum_bar', '', 'farming:cotton'},
		{'minerdream:platinum_bar', 'farming:cotton', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:bow_cobalt',
	recipe = {
		{'', 'minerdream:cobalt_bar', 'minerdream:cobalt_bar'},
		{'minerdream:cobalt_bar', '', 'farming:cotton'},
		{'minerdream:cobalt_bar', 'farming:cotton', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:bow_ruthenium',
	recipe = {
		{'', 'minerdream:ruthenium_bar', 'minerdream:ruthenium_bar'},
		{'minerdream:ruthenium_bar', '', 'farming:cotton'},
		{'minerdream:ruthenium_bar', 'farming:cotton', ''},
	}
})

------------unusualweapons and ammo------------

minetest.register_craft({
	output = 'minerdream:amethyst_staff',
	recipe = {
		{'', 'minerdream:amethyst', 'minerdream:cobalt_bar'},
		{'', 'minerdream:cobalt_bar', 'minerdream:cobalt_bar'},
		{'minerdream:amethyst', '', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:arrow 20',
	recipe = {
		{'', '', 'default:paper'},
		{'default:steel_ingot', 'group:wood', 'group:wood'},
		{'', '', 'default:paper'},

	}
})

minetest.register_craft({
	output = 'minerdream:arrow 20',
	recipe = {
		{'', '', 'mobs:chicken_feather'},
		{'default:steel_ingot', 'group:wood', 'group:wood'},
		{'', '', 'mobs:chicken_feather'},

	}
})

minetest.register_craft({
	output = 'minerdream:arrow 20',
	recipe = {
		{'', '', 'default:paper'},
		{'default:flint', 'group:wood', 'group:wood'},
		{'', '', 'default:paper'},

	}
})

minetest.register_craft({
	output = 'minerdream:arrow 20',
	recipe = {
		{'', '', 'mobs:chicken_feather'},
		{'default:flint', 'group:wood', 'group:wood'},
		{'', '', 'mobs:chicken_feather'},

	}
})

minetest.register_craft({
	output = 'minerdream:bullet 50',
	recipe = {
		{'', 'minerdream:lead_bar', ''},
		{'minerdream:brass_bar', 'tnt:gunpowder', 'minerdream:brass_bar'},
		{'minerdream:brass_bar', 'default:steel_ingot', 'minerdream:brass_bar'},

	}
})

minetest.register_craft({
	output = 'minerdream:handgun',
	recipe = {
		{'default:steel_ingot', 'default:steel_ingot', 'default:steel_ingot'},
		{'', 'default:mese_crystal_fragment', 'minerdream:lead_bar'},
		{'', '', 'minerdream:lead_bar'},
	}
})

minetest.register_craft({
	output = 'minerdream:golden_crystal_trisword',
	recipe = {
		{'', 'minerdream:topaz', 'minerdream:topaz'},
		{'minerdream:ruthenium_bar', 'default:mese', 'minerdream:topaz'},
		{'minerdream:ruthenium_bar', 'minerdream:ruthenium_bar', ''},
	}
})

-----------------------tools------------------

minetest.register_craft({
	output = 'minerdream:pick_nickel',
	recipe = {
		{'minerdream:nickel_bar', 'minerdream:nickel_bar', 'minerdream:nickel_bar'},
		{'', 'group:stick', ''},
		{'', 'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:shovel_nickel',
	recipe = {
		{'', 'minerdream:nickel_bar', ''},
		{'', 'group:stick', ''},
		{'', 'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:sword_nickel',
	recipe = {
		{'', 'minerdream:nickel_bar', ''},
		{'', 'minerdream:nickel_bar', ''},
		{'', 'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:axe_nickel',
	recipe = {
		{'minerdream:nickel_bar', 'minerdream:nickel_bar', ''},
		{'minerdream:nickel_bar', 'group:stick', ''},
		{'', 'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:axe_nickel',
	recipe = {
		{'', 'minerdream:nickel_bar', 'minerdream:nickel_bar'},
		{'', 'group:stick', 'minerdream:nickel_bar'},
		{'', 'group:stick', ''},
	}
})


minetest.register_craft({
	output = 'minerdream:pick_silver',
	recipe = {
		{'minerdream:silver_bar', 'minerdream:silver_bar', 'minerdream:silver_bar'},
		{'', 'group:stick', ''},
		{'', 'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:shovel_silver',
	recipe = {
		{'', 'minerdream:silver_bar', ''},
		{'', 'group:stick', ''},
		{'', 'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:sword_silver',
	recipe = {
		{'', 'minerdream:silver_bar', ''},
		{'', 'minerdream:silver_bar', ''},
		{'', 'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:axe_silver',
	recipe = {
		{'minerdream:silver_bar', 'minerdream:silver_bar', ''},
		{'minerdream:silver_bar', 'group:stick', ''},
		{'', 'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:axe_silver',
	recipe = {
		{'', 'minerdream:silver_bar', 'minerdream:silver_bar'},
		{'', 'group:stick', 'minerdream:silver_bar'},
		{'', 'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:pick_gold',
	recipe = {
		{'default:gold_ingot', 'default:gold_ingot', 'default:gold_ingot'},
		{'', 'group:stick', ''},
		{'', 'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:shovel_gold',
	recipe = {
		{'', 'default:gold_ingot', ''},
		{'', 'group:stick', ''},
		{'', 'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:sword_gold',
	recipe = {
		{'', 'default:gold_ingot', ''},
		{'', 'default:gold_ingot', ''},
		{'', 'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:axe_gold',
	recipe = {
		{'default:gold_ingot', 'default:gold_ingot', ''},
		{'default:gold_ingot', 'group:stick', ''},
		{'', 'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:axe_gold',
	recipe = {
		{'', 'default:gold_ingot', 'default:gold_ingot'},
		{'', 'group:stick', 'default:gold_ingot'},
		{'', 'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:pick_lead',
	recipe = {
		{'minerdream:lead_bar', 'minerdream:lead_bar', 'minerdream:lead_bar'},
		{'', 'group:stick', ''},
		{'', 'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:shovel_lead',
	recipe = {
		{'', 'minerdream:lead_bar', ''},
		{'', 'group:stick', ''},
		{'', 'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:sword_lead',
	recipe = {
		{'', 'minerdream:lead_bar', ''},
		{'', 'minerdream:lead_bar', ''},
		{'', 'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:axe_lead',
	recipe = {
		{'minerdream:lead_bar', 'minerdream:lead_bar', ''},
		{'minerdream:lead_bar', 'group:stick', ''},
		{'', 'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:axe_lead',
	recipe = {
		{'', 'minerdream:lead_bar', 'minerdream:lead_bar'},
		{'', 'group:stick', 'minerdream:lead_bar'},
		{'', 'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:pick_stainlesssteel',
	recipe = {
		{'minerdream:stainlesssteel_bar', 'minerdream:stainlesssteel_bar', 'minerdream:stainlesssteel_bar'},
		{'', 'group:stick', ''},
		{'', 'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:shovel_stainlesssteel',
	recipe = {
		{'', 'minerdream:stainlesssteel_bar', ''},
		{'', 'group:stick', ''},
		{'', 'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:sword_stainlesssteel',
	recipe = {
		{'', 'minerdream:stainlesssteel_bar', ''},
		{'', 'minerdream:stainlesssteel_bar', ''},
		{'', 'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:axe_stainlesssteel',
	recipe = {
		{'minerdream:stainlesssteel_bar', 'minerdream:stainlesssteel_bar', ''},
		{'minerdream:stainlesssteel_bar', 'group:stick', ''},
		{'', 'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:axe_stainlesssteel',
	recipe = {
		{'', 'minerdream:stainlesssteel_bar', 'minerdream:stainlesssteel_bar'},
		{'', 'group:stick', 'minerdream:stainlesssteel_bar'},
		{'', 'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:pick_aluminum',
	recipe = {
		{'minerdream:aluminum_bar', 'minerdream:aluminum_bar', 'minerdream:aluminum_bar'},
		{'', 'group:stick', ''},
		{'', 'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:shovel_aluminum',
	recipe = {
		{'', 'minerdream:aluminum_bar', ''},
		{'', 'group:stick', ''},
		{'', 'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:sword_aluminum',
	recipe = {
		{'', 'minerdream:aluminum_bar', ''},
		{'', 'minerdream:aluminum_bar', ''},
		{'', 'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:axe_aluminum',
	recipe = {
		{'minerdream:aluminum_bar', 'minerdream:aluminum_bar', ''},
		{'minerdream:aluminum_bar', 'group:stick', ''},
		{'', 'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:axe_aluminum',
	recipe = {
		{'', 'minerdream:aluminum_bar', 'minerdream:aluminum_bar'},
		{'', 'group:stick', 'minerdream:aluminum_bar'},
		{'', 'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:pick_platinum',
	recipe = {
		{'minerdream:platinum_bar', 'minerdream:platinum_bar', 'minerdream:platinum_bar'},
		{'', 'group:stick', ''},
		{'', 'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:shovel_platinum',
	recipe = {
		{'', 'minerdream:platinum_bar', ''},
		{'', 'group:stick', ''},
		{'', 'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:sword_platinum',
	recipe = {
		{'', 'minerdream:platinum_bar', ''},
		{'', 'minerdream:platinum_bar', ''},
		{'', 'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:axe_platinum',
	recipe = {
		{'minerdream:platinum_bar', 'minerdream:platinum_bar', ''},
		{'minerdream:platinum_bar', 'group:stick', ''},
		{'', 'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:axe_platinum',
	recipe = {
		{'', 'minerdream:platinum_bar', 'minerdream:platinum_bar'},
		{'', 'group:stick', 'minerdream:platinum_bar'},
		{'', 'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:pick_flint',
	recipe = {
		{'default:flint', 'default:flint', 'default:flint'},
		{'', 'group:stick', ''},
		{'', 'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:shovel_flint',
	recipe = {
		{'', 'default:flint', ''},
		{'', 'group:stick', ''},
		{'', 'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:sword_flint',
	recipe = {
		{'', 'default:flint', ''},
		{'', 'default:flint', ''},
		{'', 'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:axe_flint',
	recipe = {
		{'default:flint', 'default:flint', ''},
		{'default:flint', 'group:stick', ''},
		{'', 'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:axe_flint',
	recipe = {
		{'', 'default:flint', 'default:flint'},
		{'', 'group:stick', 'default:flint'},
		{'', 'group:stick', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:pick_cobalt',
	recipe = {
		{'minerdream:cobalt_bar', 'minerdream:cobalt_bar', 'minerdream:cobalt_bar'},
		{'', 'minerdream:steelstick', ''},
		{'', 'minerdream:steelstick', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:shovel_cobalt',
	recipe = {
		{'', 'minerdream:cobalt_bar', ''},
		{'', 'minerdream:steelstick', ''},
		{'', 'minerdream:steelstick', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:sword_cobalt',
	recipe = {
		{'', 'minerdream:cobalt_bar', ''},
		{'', 'minerdream:cobalt_bar', ''},
		{'', 'minerdream:steelstick', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:axe_cobalt',
	recipe = {
		{'minerdream:cobalt_bar', 'minerdream:cobalt_bar', ''},
		{'minerdream:cobalt_bar', 'minerdream:steelstick', ''},
		{'', 'minerdream:steelstick', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:axe_cobalt',
	recipe = {
		{'', 'minerdream:cobalt_bar', 'minerdream:cobalt_bar'},
		{'', 'minerdream:steelstick', 'minerdream:cobalt_bar'},
		{'', 'minerdream:steelstick', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:pick_ruthenium',
	recipe = {
		{'minerdream:ruthenium_bar', 'minerdream:ruthenium_bar', 'minerdream:ruthenium_bar'},
		{'', 'minerdream:steelstick', ''},
		{'', 'minerdream:steelstick', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:shovel_ruthenium',
	recipe = {
		{'', 'minerdream:ruthenium_bar', ''},
		{'', 'minerdream:steelstick', ''},
		{'', 'minerdream:steelstick', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:sword_ruthenium',
	recipe = {
		{'', 'minerdream:ruthenium_bar', ''},
		{'', 'minerdream:ruthenium_bar', ''},
		{'', 'minerdream:steelstick', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:axe_ruthenium',
	recipe = {
		{'minerdream:ruthenium_bar', 'minerdream:ruthenium_bar', ''},
		{'minerdream:ruthenium_bar', 'minerdream:steelstick', ''},
		{'', 'minerdream:steelstick', ''},
	}
})

minetest.register_craft({
	output = 'minerdream:axe_ruthenium',
	recipe = {
		{'', 'minerdream:ruthenium_bar', 'minerdream:ruthenium_bar'},
		{'', 'minerdream:steelstick', 'minerdream:ruthenium_bar'},
		{'', 'minerdream:steelstick', ''},
	}
})



-------------------armor-------------

minetest.register_craft({
	output = 'minerdream:helmet_nickel',
	recipe = {
		{'minerdream:nickel_bar', 'minerdream:nickel_bar', 'minerdream:nickel_bar'},
		{'minerdream:nickel_bar', '', 'minerdream:nickel_bar'},

	}
})

minetest.register_craft({
	output = 'minerdream:chestplate_nickel',
	recipe = {
		{'minerdream:nickel_bar', '', 'minerdream:nickel_bar'},
		{'minerdream:nickel_bar', 'minerdream:nickel_bar', 'minerdream:nickel_bar'},
		{'minerdream:nickel_bar', 'minerdream:nickel_bar', 'minerdream:nickel_bar'},

	}
})

minetest.register_craft({
	output = 'minerdream:leggings_nickel',
	recipe = {
		{'minerdream:nickel_bar', 'minerdream:nickel_bar', 'minerdream:nickel_bar'},
		{'minerdream:nickel_bar', '', 'minerdream:nickel_bar'},
		{'minerdream:nickel_bar', '', 'minerdream:nickel_bar'},

	}
})

minetest.register_craft({
	output = 'minerdream:boots_nickel',
	recipe = {
		{'minerdream:nickel_bar', '', 'minerdream:nickel_bar'},
		{'minerdream:nickel_bar', '', 'minerdream:nickel_bar'},

	}
})

minetest.register_craft({
	output = 'minerdream:shield_nickel',
	recipe = {
		{'minerdream:nickel_bar', 'minerdream:nickel_bar', 'minerdream:nickel_bar'},
		{'minerdream:nickel_bar', 'minerdream:nickel_bar', 'minerdream:nickel_bar'},
		{'', 'minerdream:nickel_bar', ''},

	}
})

minetest.register_craft({
	output = 'minerdream:helmet_silver',
	recipe = {
		{'minerdream:silver_bar', 'minerdream:silver_bar', 'minerdream:silver_bar'},
		{'minerdream:silver_bar', '', 'minerdream:silver_bar'},

	}
})

minetest.register_craft({
	output = 'minerdream:chestplate_silver',
	recipe = {
		{'minerdream:silver_bar', '', 'minerdream:silver_bar'},
		{'minerdream:silver_bar', 'minerdream:silver_bar', 'minerdream:silver_bar'},
		{'minerdream:silver_bar', 'minerdream:silver_bar', 'minerdream:silver_bar'},

	}
})

minetest.register_craft({
	output = 'minerdream:leggings_silver',
	recipe = {
		{'minerdream:silver_bar', 'minerdream:silver_bar', 'minerdream:silver_bar'},
		{'minerdream:silver_bar', '', 'minerdream:silver_bar'},
		{'minerdream:silver_bar', '', 'minerdream:silver_bar'},

	}
})

minetest.register_craft({
	output = 'minerdream:boots_silver',
	recipe = {
		{'minerdream:silver_bar', '', 'minerdream:silver_bar'},
		{'minerdream:silver_bar', '', 'minerdream:silver_bar'},

	}
})

minetest.register_craft({
	output = 'minerdream:shield_silver',
	recipe = {
		{'minerdream:silver_bar', 'minerdream:silver_bar', 'minerdream:silver_bar'},
		{'minerdream:silver_bar', 'minerdream:silver_bar', 'minerdream:silver_bar'},
		{'', 'minerdream:silver_bar', ''},

	}
})

minetest.register_craft({
	output = 'minerdream:helmet_lead',
	recipe = {
		{'minerdream:lead_bar', 'minerdream:lead_bar', 'minerdream:lead_bar'},
		{'minerdream:lead_bar', '', 'minerdream:lead_bar'},

	}
})

minetest.register_craft({
	output = 'minerdream:chestplate_lead',
	recipe = {
		{'minerdream:lead_bar', '', 'minerdream:lead_bar'},
		{'minerdream:lead_bar', 'minerdream:lead_bar', 'minerdream:lead_bar'},
		{'minerdream:lead_bar', 'minerdream:lead_bar', 'minerdream:lead_bar'},

	}
})

minetest.register_craft({
	output = 'minerdream:leggings_lead',
	recipe = {
		{'minerdream:lead_bar', 'minerdream:lead_bar', 'minerdream:lead_bar'},
		{'minerdream:lead_bar', '', 'minerdream:lead_bar'},
		{'minerdream:lead_bar', '', 'minerdream:lead_bar'},

	}
})

minetest.register_craft({
	output = 'minerdream:boots_lead',
	recipe = {
		{'minerdream:lead_bar', '', 'minerdream:lead_bar'},
		{'minerdream:lead_bar', '', 'minerdream:lead_bar'},

	}
})

minetest.register_craft({
	output = 'minerdream:shield_lead',
	recipe = {
		{'minerdream:lead_bar', 'minerdream:lead_bar', 'minerdream:lead_bar'},
		{'minerdream:lead_bar', 'minerdream:lead_bar', 'minerdream:lead_bar'},
		{'', 'minerdream:lead_bar', ''},

	}
})

minetest.register_craft({
	output = 'minerdream:helmet_aluminum',
	recipe = {
		{'minerdream:aluminum_bar', 'minerdream:aluminum_bar', 'minerdream:aluminum_bar'},
		{'minerdream:aluminum_bar', '', 'minerdream:aluminum_bar'},

	}
})

minetest.register_craft({
	output = 'minerdream:chestplate_aluminum',
	recipe = {
		{'minerdream:aluminum_bar', '', 'minerdream:aluminum_bar'},
		{'minerdream:aluminum_bar', 'minerdream:aluminum_bar', 'minerdream:aluminum_bar'},
		{'minerdream:aluminum_bar', 'minerdream:aluminum_bar', 'minerdream:aluminum_bar'},

	}
})

minetest.register_craft({
	output = 'minerdream:leggings_aluminum',
	recipe = {
		{'minerdream:aluminum_bar', 'minerdream:aluminum_bar', 'minerdream:aluminum_bar'},
		{'minerdream:aluminum_bar', '', 'minerdream:aluminum_bar'},
		{'minerdream:aluminum_bar', '', 'minerdream:aluminum_bar'},

	}
})

minetest.register_craft({
	output = 'minerdream:boots_aluminum',
	recipe = {
		{'minerdream:aluminum_bar', '', 'minerdream:aluminum_bar'},
		{'minerdream:aluminum_bar', '', 'minerdream:aluminum_bar'},

	}
})

minetest.register_craft({
	output = 'minerdream:shield_aluminum',
	recipe = {
		{'minerdream:aluminum_bar', 'minerdream:aluminum_bar', 'minerdream:aluminum_bar'},
		{'minerdream:aluminum_bar', 'minerdream:aluminum_bar', 'minerdream:aluminum_bar'},
		{'', 'minerdream:aluminum_bar', ''},

	}
})

minetest.register_craft({
	output = 'minerdream:helmet_stainlesssteel',
	recipe = {
		{'minerdream:stainlesssteel_bar', 'minerdream:stainlesssteel_bar', 'minerdream:stainlesssteel_bar'},
		{'minerdream:stainlesssteel_bar', '', 'minerdream:stainlesssteel_bar'},

	}
})

minetest.register_craft({
	output = 'minerdream:chestplate_stainlesssteel',
	recipe = {
		{'minerdream:stainlesssteel_bar', '', 'minerdream:stainlesssteel_bar'},
		{'minerdream:stainlesssteel_bar', 'minerdream:stainlesssteel_bar', 'minerdream:stainlesssteel_bar'},
		{'minerdream:stainlesssteel_bar', 'minerdream:stainlesssteel_bar', 'minerdream:stainlesssteel_bar'},

	}
})

minetest.register_craft({
	output = 'minerdream:leggings_stainlesssteel',
	recipe = {
		{'minerdream:stainlesssteel_bar', 'minerdream:stainlesssteel_bar', 'minerdream:stainlesssteel_bar'},
		{'minerdream:stainlesssteel_bar', '', 'minerdream:stainlesssteel_bar'},
		{'minerdream:stainlesssteel_bar', '', 'minerdream:stainlesssteel_bar'},

	}
})

minetest.register_craft({
	output = 'minerdream:boots_stainlesssteel',
	recipe = {
		{'minerdream:stainlesssteel_bar', '', 'minerdream:stainlesssteel_bar'},
		{'minerdream:stainlesssteel_bar', '', 'minerdream:stainlesssteel_bar'},

	}
})

minetest.register_craft({
	output = 'minerdream:shield_stainlesssteel',
	recipe = {
		{'minerdream:stainlesssteel_bar', 'minerdream:stainlesssteel_bar', 'minerdream:stainlesssteel_bar'},
		{'minerdream:stainlesssteel_bar', 'minerdream:stainlesssteel_bar', 'minerdream:stainlesssteel_bar'},
		{'', 'minerdream:stainlesssteel_bar', ''},

	}
})

minetest.register_craft({
	output = 'minerdream:helmet_platinum',
	recipe = {
		{'minerdream:platinum_bar', 'minerdream:platinum_bar', 'minerdream:platinum_bar'},
		{'minerdream:platinum_bar', '', 'minerdream:platinum_bar'},

	}
})

minetest.register_craft({
	output = 'minerdream:chestplate_platinum',
	recipe = {
		{'minerdream:platinum_bar', '', 'minerdream:platinum_bar'},
		{'minerdream:platinum_bar', 'minerdream:platinum_bar', 'minerdream:platinum_bar'},
		{'minerdream:platinum_bar', 'minerdream:platinum_bar', 'minerdream:platinum_bar'},

	}
})

minetest.register_craft({
	output = 'minerdream:leggings_platinum',
	recipe = {
		{'minerdream:platinum_bar', 'minerdream:platinum_bar', 'minerdream:platinum_bar'},
		{'minerdream:platinum_bar', '', 'minerdream:platinum_bar'},
		{'minerdream:platinum_bar', '', 'minerdream:platinum_bar'},

	}
})

minetest.register_craft({
	output = 'minerdream:boots_platinum',
	recipe = {
		{'minerdream:platinum_bar', '', 'minerdream:platinum_bar'},
		{'minerdream:platinum_bar', '', 'minerdream:platinum_bar'},

	}
})

minetest.register_craft({
	output = 'minerdream:shield_platinum',
	recipe = {
		{'minerdream:platinum_bar', 'minerdream:platinum_bar', 'minerdream:platinum_bar'},
		{'minerdream:platinum_bar', 'minerdream:platinum_bar', 'minerdream:platinum_bar'},
		{'', 'minerdream:platinum_bar', ''},

	}
})


minetest.register_craft({
	output = 'minerdream:helmet_cobalt',
	recipe = {
		{'minerdream:cobalt_bar', 'minerdream:cobalt_bar', 'minerdream:cobalt_bar'},
		{'minerdream:cobalt_bar', '', 'minerdream:cobalt_bar'},

	}
})

minetest.register_craft({
	output = 'minerdream:chestplate_cobalt',
	recipe = {
		{'minerdream:cobalt_bar', '', 'minerdream:cobalt_bar'},
		{'minerdream:cobalt_bar', 'minerdream:cobalt_bar', 'minerdream:cobalt_bar'},
		{'minerdream:cobalt_bar', 'minerdream:cobalt_bar', 'minerdream:cobalt_bar'},

	}
})

minetest.register_craft({
	output = 'minerdream:leggings_cobalt',
	recipe = {
		{'minerdream:cobalt_bar', 'minerdream:cobalt_bar', 'minerdream:cobalt_bar'},
		{'minerdream:cobalt_bar', '', 'minerdream:cobalt_bar'},
		{'minerdream:cobalt_bar', '', 'minerdream:cobalt_bar'},

	}
})

minetest.register_craft({
	output = 'minerdream:boots_cobalt',
	recipe = {
		{'minerdream:cobalt_bar', '', 'minerdream:cobalt_bar'},
		{'minerdream:cobalt_bar', '', 'minerdream:cobalt_bar'},

	}
})

minetest.register_craft({
	output = 'minerdream:shield_cobalt',
	recipe = {
		{'minerdream:cobalt_bar', 'minerdream:cobalt_bar', 'minerdream:cobalt_bar'},
		{'minerdream:cobalt_bar', 'minerdream:cobalt_bar', 'minerdream:cobalt_bar'},
		{'', 'minerdream:cobalt_bar', ''},

	}
})

minetest.register_craft({
	output = 'minerdream:helmet_ruthenium',
	recipe = {
		{'minerdream:ruthenium_bar', 'minerdream:ruthenium_bar', 'minerdream:ruthenium_bar'},
		{'minerdream:ruthenium_bar', '', 'minerdream:ruthenium_bar'},

	}
})

minetest.register_craft({
	output = 'minerdream:chestplate_ruthenium',
	recipe = {
		{'minerdream:ruthenium_bar', '', 'minerdream:ruthenium_bar'},
		{'minerdream:ruthenium_bar', 'minerdream:ruthenium_bar', 'minerdream:ruthenium_bar'},
		{'minerdream:ruthenium_bar', 'minerdream:ruthenium_bar', 'minerdream:ruthenium_bar'},

	}
})

minetest.register_craft({
	output = 'minerdream:leggings_ruthenium',
	recipe = {
		{'minerdream:ruthenium_bar', 'minerdream:ruthenium_bar', 'minerdream:ruthenium_bar'},
		{'minerdream:ruthenium_bar', '', 'minerdream:ruthenium_bar'},
		{'minerdream:ruthenium_bar', '', 'minerdream:ruthenium_bar'},

	}
})

minetest.register_craft({
	output = 'minerdream:boots_ruthenium',
	recipe = {
		{'minerdream:ruthenium_bar', '', 'minerdream:ruthenium_bar'},
		{'minerdream:ruthenium_bar', '', 'minerdream:ruthenium_bar'},

	}
})

minetest.register_craft({
	output = 'minerdream:shield_ruthenium',
	recipe = {
		{'minerdream:ruthenium_bar', 'minerdream:ruthenium_bar', 'minerdream:ruthenium_bar'},
		{'minerdream:ruthenium_bar', 'minerdream:ruthenium_bar', 'minerdream:ruthenium_bar'},
		{'', 'minerdream:ruthenium_bar', ''},

	}
})

------special armors-----

minetest.register_craft({
	output = 'minerdream:helmet_scout',
	recipe = {
		{'', 'minerdream:amethyst', ''},
		{'default:gold_ingot', 'minerdream:helmet_cobalt', 'default:gold_ingot'},

	}
})

minetest.register_craft({
	output = 'minerdream:chestplate_scout',
	recipe = {
		{'minerdream:amethyst', '', 'minerdream:amethyst'},
		{'default:gold_ingot', 'minerdream:chestplate_cobalt', 'default:gold_ingot'},
		{'default:gold_ingot', 'default:gold_ingot', 'default:gold_ingot'},

	}
})

minetest.register_craft({
	output = 'minerdream:leggings_scout',
	recipe = {
		{'', 'default:gold_ingot', ''},
		{'minerdream:amethyst', 'minerdream:leggings_cobalt', 'minerdream:amethyst'},
		{'', '', ''},

	}
})

minetest.register_craft({
	output = 'minerdream:boots_scout',
	recipe = {
		{'', '', ''},
		{'minerdream:amethyst', 'minerdream:boots_cobalt', 'minerdream:amethyst'},
		{'default:gold_ingot', '', 'default:gold_ingot'},

	}
})

minetest.register_craft({
	output = 'minerdream:shield_scout',
	recipe = {
		{'', 'default:gold_ingot', ''},
		{'default:gold_ingot', 'minerdream:amethyst', 'default:gold_ingot'},
		{'', 'minerdream:shield_cobalt', ''},

	}
})

minetest.register_craft({
	output = 'minerdream:helmet_defender',
	recipe = {
		{'', 'minerdream:topaz', ''},
		{'default:bronze_ingot', 'minerdream:helmet_ruthenium', 'default:bronze_ingot'},

	}
})

minetest.register_craft({
	output = 'minerdream:chestplate_defender',
	recipe = {
		{'minerdream:topaz', '', 'minerdream:topaz'},
		{'default:bronze_ingot', 'minerdream:chestplate_ruthenium', 'default:bronze_ingot'},
		{'default:bronze_ingot', 'default:bronze_ingot', 'default:bronze_ingot'},

	}
})

minetest.register_craft({
	output = 'minerdream:leggings_defender',
	recipe = {
		{'', 'default:bronze_ingot', ''},
		{'minerdream:topaz', 'minerdream:leggings_ruthenium', 'minerdream:topaz'},
		{'', '', ''},

	}
})

minetest.register_craft({
	output = 'minerdream:boots_defender',
	recipe = {
		{'', '', ''},
		{'minerdream:topaz', 'minerdream:boots_ruthenium', 'minerdream:topaz'},
		{'default:bronze_ingot', '', 'default:bronze_ingot'},

	}
})

minetest.register_craft({
	output = 'minerdream:shield_defender',
	recipe = {
		{'', 'default:bronze_ingot', ''},
		{'default:bronze_ingot', 'minerdream:topaz', 'default:bronze_ingot'},
		{'', 'minerdream:shield_ruthenium', ''},

	}
})



