-------------ores--------------

minetest.register_node("minerdream:stone_with_topaz", {
	description = "Topaz ore",
	tiles = {"default_stone.png^minerdream_topaz_ore.png"},
	groups = {cracky = 4},
	drop = 'minerdream:topaz',
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("minerdream:stone_with_amethyst", {
	description = "amethyst ore",
	tiles = {"default_stone.png^minerdream_amethyst_ore.png"},
	groups = {cracky = 4},
	drop = 'minerdream:amethyst',
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("minerdream:stone_with_ruthenium", {
	description = "Ruthenium ore",
	tiles = {"default_stone.png^minerdream_ruthenium_ore.png"},
	groups = {cracky = 4},
	drop = 'minerdream:ruthenium_lump',
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("minerdream:stone_with_cobalt", {
	description = "Cobalt ore",
	tiles = {"default_stone.png^minerdream_cobalt_ore.png"},
	groups = {cracky = 4},
	drop = 'minerdream:cobalt_lump',
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("minerdream:stone_with_platinum", {
	description = "Platinum ore",
	tiles = {"default_stone.png^minerdream_platinum_ore.png"},
	groups = {cracky = 1},
	drop = 'minerdream:platinum_lump',
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("minerdream:stone_with_aluminum", {
	description = "Aluminum ore",
	tiles = {"default_stone.png^minerdream_aluminum_ore.png"},
	groups = {cracky = 1},
	drop = 'minerdream:aluminum_lump',
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("minerdream:stone_with_zinc", {
	description = "Zinc Ore",
	tiles = {"default_stone.png^minerdream_zinc_ore.png"},
	groups = {cracky = 1},
	drop = 'minerdream:zinc_lump',
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("minerdream:stone_with_lead", {
	description = "Lead Ore",
	tiles = {"default_stone.png^minerdream_lead_ore.png"},
	groups = {cracky = 2},
	drop = 'minerdream:lead_lump',
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("minerdream:stone_with_silver", {
	description = "Silver Ore",
	tiles = {"default_stone.png^minerdream_silver_ore.png"},
	groups = {cracky = 2},
	drop = 'minerdream:silver_lump',
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("minerdream:stone_with_calcium", {
	description = "Calcium Ore",
	tiles = {"default_stone.png^minerdream_calcium_ore.png"},
	groups = {cracky = 3},
	drop = 'minerdream:calcium_lump',
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("minerdream:stone_with_potassium", {
	description = "Potassium Ore",
	tiles = {"default_stone.png^minerdream_potassium_ore.png"},
	groups = {cracky = 3},
	drop = 'minerdream:potassium_lump',
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("minerdream:stone_with_nickel", {
	description = "Nickel Ore",
	tiles = {"default_stone.png^minerdream_nickel_ore.png"},
	groups = {cracky = 2},
	drop = 'minerdream:nickel_lump',
	sounds = default.node_sound_stone_defaults(),
})

---------------blox-----------

minetest.register_node("minerdream:ruthenium_block", {
	description = "Ruthenium block",
	tiles = {"minerdream_ruthenium_block.png"},
	groups = {cracky = 3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("minerdream:cobalt_block", {
	description = "Cobalt block",
	tiles = {"minerdream_cobalt_block.png"},
	groups = {cracky = 3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("minerdream:platinum_block", {
	description = "Platinum block",
	tiles = {"minerdream_platinum_block.png"},
	groups = {cracky = 3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("minerdream:aluminum_block", {
	description = "Aluminum block",
	tiles = {"minerdream_aluminum_block.png"},
	groups = {cracky = 3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("minerdream:brass_block", {
	description = "Brass block",
	tiles = {"minerdream_brass_block.png"},
	groups = {cracky = 3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("minerdream:lead_block", {
	description = "Lead block",
	tiles = {"minerdream_lead_block.png"},
	groups = {cracky = 3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("minerdream:zinc_block", {
	description = "Zinc block",
	tiles = {"minerdream_zinc_block.png"},
	groups = {cracky = 3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("minerdream:calcium_block", {
	description = "Calcium block",
	tiles = {"minerdream_calcium_block.png"},
	groups = {cracky = 3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("minerdream:potassium_block", {
	description = "Potassium block",
	tiles = {"minerdream_potassium_block.png"},
	groups = {cracky = 3},
	sounds = default.node_sound_stone_defaults(),
})


minetest.register_node("minerdream:nickel_block", {
	description = "Nickel block",
	tiles = {"minerdream_nickel_block.png"},
	groups = {cracky = 2},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("minerdream:silver_block", {
	description = "Silver block",
	tiles = {"minerdream_silver_block.png"},
	groups = {cracky = 2},
	sounds = default.node_sound_stone_defaults(),
})

---------------brix----------

minetest.register_node("minerdream:ruthenium_brick", {
	description = "Ruthenium bricks",
	tiles = {"minerdream_ruthenium_brick.png"},
	groups = {cracky = 3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("minerdream:cobalt_brick", {
	description = "Cobalt bricks",
	tiles = {"minerdream_cobalt_brick.png"},
	groups = {cracky = 3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("minerdream:platinum_brick", {
	description = "Platinum bricks",
	tiles = {"minerdream_platinum_brick.png"},
	groups = {cracky = 3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("minerdream:aluminum_brick", {
	description = "Aluminum bricks",
	tiles = {"minerdream_aluminum_brick.png"},
	groups = {cracky = 3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("minerdream:brass_brick", {
	description = "Brass bricks",
	tiles = {"minerdream_brass_brick.png"},
	groups = {cracky = 3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("minerdream:lead_brick", {
	description = "Lead bricks",
	tiles = {"minerdream_lead_brick.png"},
	groups = {cracky = 3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("minerdream:zinc_brick", {
	description = "Zinc bricks",
	tiles = {"minerdream_zinc_brick.png"},
	groups = {cracky = 3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("minerdream:copper_brick", {
	description = "Copper bricks",
	tiles = {"minerdream_copper_brick.png"},
	groups = {cracky = 3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("minerdream:tin_brick", {
	description = "Tin bricks",
	tiles = {"minerdream_tin_brick.png"},
	groups = {cracky = 3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("minerdream:iron_brick", {
	description = "Iron bricks",
	tiles = {"minerdream_iron_brick.png"},
	groups = {cracky = 3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("minerdream:gold_brick", {
	description = "Golden bricks",
	tiles = {"minerdream_gold_brick.png"},
	groups = {cracky = 3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("minerdream:potassium_brick", {
	description = "Potassium bricks",
	tiles = {"minerdream_potassium_brick.png"},
	groups = {cracky = 3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("minerdream:calcium_brick", {
	description = "Calcium bricks",
	tiles = {"minerdream_calcium_brick.png"},
	groups = {cracky = 3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("minerdream:nickel_brick", {
	description = "Nickel bricks",
	tiles = {"minerdream_nickel_brick.png"},
	groups = {cracky = 3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node("minerdream:silver_brick", {
	description = "Silver bricks",
	tiles = {"minerdream_silver_brick.png"},
	groups = {cracky = 3},
	sounds = default.node_sound_stone_defaults(),
})
-------------gemstones---------------
minetest.register_node("minerdream:amethyst", {
		description = "".. core.colorize("#0040FF", "Amethyst gemstone\n")..core.colorize("#A0A0A0", "tier: 5 (extra rare)"),
	drawtype = "mesh",
	mesh = "amethyst.obj",
	walkable = "true",
	inventory_image = "minerdream_amethyst_gem.png",
	tiles = {"minerdream_amethyst.png"},
	paramtype = "light",
	is_ground_content = true,
	stack_max= 200,
	groups = {snappy=3,dig_immediate=3},
	selection_box = {
		type = "fixed",
		fixed = {
			{-0.2, -0.5, -0.2, 0.2, -0.25, 0.2},
		},
	},
	node_box = {
		type = "fixed",
		fixed = {
			{-0.2, -0.5, -0.2, 0.2, -0.25, 0.2},
		},
	},
})

minetest.register_node("minerdream:topaz", {
		description = "".. core.colorize("#0040FF", "Topaz gemstone\n")..core.colorize("#A0A0A0", "tier: 5 (extra rare)"),
	drawtype = "mesh",
	mesh = "topaz.obj",
	walkable = "true",
	inventory_image = "minerdream_topaz_gem.png",
	tiles = {"minerdream_topaz.png"},
	paramtype = "light",
	stack_max= 200,
	is_ground_content = true,
	groups = {snappy=3,dig_immediate=3},
	selection_box = {
		type = "fixed",
		fixed = {
			{-0.2, -0.5, -0.2, 0.2, -0.25, 0.2},
		},
	},
	node_box = {
		type = "fixed",
		fixed = {
			{-0.2, -0.5, -0.2, 0.2, -0.25, 0.2},
		},
	},
})

-------------bars---------------------

minetest.register_node("minerdream:ruthenium_bar_block", {
	description = "Ruthenium bar stack",
	drawtype = "mesh",
	mesh = "bars.obj",
	tiles = {"minerdream_ruthenium_bar_block.png"},
	paramtype = "light",
	is_ground_content = true,
	groups = {snappy=3,dig_immediate=3},
})

minetest.register_node("minerdream:cobalt_bar_block", {
	description = "Cobalt bar stack",
	drawtype = "mesh",
	mesh = "bars.obj",
	tiles = {"minerdream_cobalt_bar_block.png"},
	paramtype = "light",
	is_ground_content = true,
	groups = {snappy=3,dig_immediate=3},
})

minetest.register_node("minerdream:platinum_bar_block", {
	description = "Platinum bar stack",
	drawtype = "mesh",
	mesh = "bars.obj",
	tiles = {"minerdream_platinum_bar_block.png"},
	paramtype = "light",
	is_ground_content = true,
	groups = {snappy=3,dig_immediate=3},
})

minetest.register_node("minerdream:aluminum_bar_block", {
	description = "Aluminum bar stack",
	drawtype = "mesh",
	mesh = "bars.obj",
	tiles = {"minerdream_aluminum_bar_block.png"},
	paramtype = "light",
	is_ground_content = true,
	groups = {snappy=3,dig_immediate=3},
})

minetest.register_node("minerdream:brass_bar_block", {
	description = "Brass bar stack",
	drawtype = "mesh",
	mesh = "bars.obj",
	tiles = {"minerdream_brass_bar_block.png"},
	paramtype = "light",
	is_ground_content = true,
	groups = {snappy=3,dig_immediate=3},
})

minetest.register_node("minerdream:zinc_bar_block", {
	description = "Zinc bar stack",
	drawtype = "mesh",
	mesh = "bars.obj",
	tiles = {"minerdream_zinc_bar_block.png"},
	paramtype = "light",
	is_ground_content = true,
	groups = {snappy=3,dig_immediate=3},
})

minetest.register_node("minerdream:lead_bar_block", {
	description = "Lead bar stack",
	drawtype = "mesh",
	mesh = "bars.obj",
	tiles = {"minerdream_lead_bar_block.png"},
	paramtype = "light",
	is_ground_content = true,
	groups = {snappy=3,dig_immediate=3},
})

minetest.register_node("minerdream:gold_bar_block", {
	description = "Gold bar stack",
	drawtype = "mesh",
	mesh = "bars.obj",
	tiles = {"minerdream_gold_bar_block.png"},
	paramtype = "light",
	is_ground_content = true,
	groups = {snappy=3,dig_immediate=3},
})

minetest.register_node("minerdream:copper_bar_block", {
	description = "Copper bar stack",
	drawtype = "mesh",
	mesh = "bars.obj",
	tiles = {"minerdream_copper_bar_block.png"},
	paramtype = "light",
	is_ground_content = true,
	groups = {snappy=3,dig_immediate=3},
})

minetest.register_node("minerdream:tin_bar_block", {
	description = "Tin bar stack",
	drawtype = "mesh",
	mesh = "bars.obj",
	tiles = {"minerdream_tin_bar_block.png"},
	paramtype = "light",
	is_ground_content = true,
	groups = {snappy=3,dig_immediate=3},
})

minetest.register_node("minerdream:steel_bar_block", {
	description = "Steel bar stack",
	drawtype = "mesh",
	mesh = "bars.obj",
	tiles = {"minerdream_steel_bar_block.png"},
	paramtype = "light",
	is_ground_content = true,
	groups = {snappy=3,dig_immediate=3},
})

minetest.register_node("minerdream:bronze_bar_block", {
	description = "Bronze bar stack",
	drawtype = "mesh",
	mesh = "bars.obj",
	tiles = {"minerdream_bronze_bar_block.png"},
	paramtype = "light",
	is_ground_content = true,
	groups = {snappy=3,dig_immediate=3},
})

minetest.register_node("minerdream:potassium_bar_block", {
	description = "Potassium bar stack",
	drawtype = "mesh",
	mesh = "bars.obj",
	tiles = {"minerdream_potassium_bar_block.png"},
	paramtype = "light",
	is_ground_content = true,
	groups = {snappy=3,dig_immediate=3},
})

minetest.register_node("minerdream:calcium_bar_block", {
	description = "calcium bar stack",
	drawtype = "mesh",
	mesh = "bars.obj",
	tiles = {"minerdream_calcium_bar_block.png"},
	paramtype = "light",
	is_ground_content = true,
	groups = {snappy=3,dig_immediate=3},
})

minetest.register_node("minerdream:nickel_bar_block", {
	description = "nickel bar stack",
	drawtype = "mesh",
	mesh = "bars.obj",
	tiles = {"minerdream_nickel_bar_block.png"},
	paramtype = "light",
	is_ground_content = true,
	groups = {snappy=3,dig_immediate=3},
})

minetest.register_node("minerdream:silver_bar_block", {
	description = "silver bar stack",
	drawtype = "mesh",
	mesh = "bars.obj",
	tiles = {"minerdream_silver_bar_block.png"},
	paramtype = "light",
	is_ground_content = true,
	groups = {snappy=3,dig_immediate=3},
})