---treasure---

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "minerdream:treasure1",
		wherein        = "default:stone",
		clust_scarcity = 8 * 8 * 8,
		clust_num_ores = 1,
		clust_size     = 1,
		y_min          = -200,
		y_max          = 50,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "minerdream:treasure2",
		wherein        = "default:stone",
		clust_scarcity = 10 * 10 * 10,
		clust_num_ores = 1,
		clust_size     = 1,
		y_min          = -400,
		y_max          = -100,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "minerdream:treasure3",
		wherein        = "default:stone",
		clust_scarcity = 12 * 12 * 12,
		clust_num_ores = 1,
		clust_size     = 1,
		y_min          = -750,
		y_max          = -250,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "minerdream:treasure4",
		wherein        = "default:stone",
		clust_scarcity = 14 * 14 * 14,
		clust_num_ores = 1,
		clust_size     = 1,
		y_min          = -1500,
		y_max          = -500,
	})


---ores---

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "minerdream:stone_with_calcium",
		wherein        = "default:stone",
		clust_scarcity = 12 * 12 * 12,
		clust_num_ores = 5,
		clust_size     = 2,
		y_min          = -31000,
		y_max          = 420,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "minerdream:stone_with_potassium",
		wherein        = "default:stone",
		clust_scarcity = 14 * 14 * 14,
		clust_num_ores = 7,
		clust_size     = 3,
		y_min          = -31000,
		y_max          = 420,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "minerdream:stone_with_nickel",
		wherein        = "default:stone",
		clust_scarcity = 13 * 13 * 13,
		clust_num_ores = 7,
		clust_size     = 3,
		y_min          = -31000,
		y_max          = -40,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "minerdream:stone_with_nickel",
		wherein        = "default:stone",
		clust_scarcity = 13 * 13 * 13,
		clust_num_ores = 7,
		clust_size     = 3,
		y_min          = -31000,
		y_max          = -40,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "minerdream:stone_with_zinc",
		wherein        = "default:stone",
		clust_scarcity = 14 * 14 * 14,
		clust_num_ores = 7,
		clust_size     = 3,
		y_min          = -31000,
		y_max          = -50,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "minerdream:stone_with_silver",
		wherein        = "default:stone",
		clust_scarcity = 15 * 15 * 15,
		clust_num_ores = 3,
		clust_size     = 2,
		y_min          = -31000,
		y_max          = -64,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "minerdream:stone_with_lead",
		wherein        = "default:stone",
		clust_scarcity = 16 * 16 * 16,
		clust_num_ores = 7,
		clust_size     = 3,
		y_min          = -31000,
		y_max          = -70,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "minerdream:stone_with_aluminum",
		wherein        = "default:stone",
		clust_scarcity = 16 * 16 * 16,
		clust_num_ores = 3,
		clust_size     = 2,
		y_min          = -31000,
		y_max          = -250,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "minerdream:stone_with_platinum",
		wherein        = "default:stone",
		clust_scarcity = 16 * 16 * 16,
		clust_num_ores = 3,
		clust_size     = 2,
		y_min          = -31000,
		y_max          = -300,
	})


	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "minerdream:stone_with_cobalt",
		wherein        = "default:stone",
		clust_scarcity = 18 * 18 * 18,
		clust_num_ores = 3,
		clust_size     = 2,
		y_min          = -31000,
		y_max          = -500,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "minerdream:stone_with_ruthenium",
		wherein        = "default:stone",
		clust_scarcity = 18 * 18 * 18,
		clust_num_ores = 3,
		clust_size     = 2,
		y_min          = -31000,
		y_max          = -500,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "minerdream:stone_with_amethyst",
		wherein        = "default:stone",
		clust_scarcity = 10 * 10 * 10,
		clust_num_ores = 1,
		clust_size     = 1,
		y_min          = -31000,
		y_max          = -650,
	})

	minetest.register_ore({
		ore_type       = "scatter",
		ore            = "minerdream:stone_with_topaz",
		wherein        = "default:stone",
		clust_scarcity = 10 * 10 * 10,
		clust_num_ores = 1,
		clust_size     = 1,
		y_min          = -31000,
		y_max          = -650,
	})

